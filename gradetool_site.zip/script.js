window.onload = function () {
  const container = document.getElementById("grade-table");
  const searchInput = document.getElementById("search-input");

  function renderGrades(filteredGrades) {
    container.innerHTML = "";

    if (filteredGrades.length === 0) {
      container.innerHTML = "<p>No matching grades found.</p>";
      return;
    }

    filteredGrades.forEach((grade) => {
      const card = document.createElement("div");
      card.className = "grade-card";

      const title = document.createElement("h4");
      title.textContent = grade.name;

      const list = document.createElement("ul");
      for (let element in grade.elements) {
        const li = document.createElement("li");
        li.textContent = `${element}: ${grade.elements[element]}`;
        list.appendChild(li);
      }

      const std = document.createElement("p");
      std.className = "standard";
      std.textContent = `Standard: ${grade.standard}`;

      card.appendChild(title);
      card.appendChild(list);
      card.appendChild(std);
      container.appendChild(card);
    });
  }

  renderGrades(grades);

  searchInput.addEventListener("input", function () {
    const query = this.value.toLowerCase().trim();

    if (!query) {
      renderGrades(grades);
      return;
    }

    const byName = grades.filter((g) =>
      g.name.toLowerCase().includes(query)
    );

    if (byName.length > 0) {
      renderGrades(byName);
      return;
    }

    const tokens = query.match(/[A-Za-z]{1,2}\s?\d+(\.\d+)?/g);

    if (!tokens) {
      container.innerHTML = "<p>Please enter valid element search terms (e.g. Cr 18 Ni 8).</p>";
      return;
    }

    const searchElems = tokens.map((token) => {
      const parts = token.split(/(?<=^[A-Za-z]{1,2})/);
      return {
        element: parts[0].toUpperCase(),
        value: parseFloat(parts[1])
      };
    });

    const filtered = grades.filter((grade) =>
      searchElems.every((input) => {
        const gradeValue = grade.elements[input.element];
        if (!gradeValue) return false;

        const numeric = gradeValue.match(/(\d+(\.\d+)?)/g);
        if (!numeric) return false;

        return numeric.some((val) => {
          const num = parseFloat(val);
          return Math.abs(num - input.value) / input.value <= 0.1;
        });
      })
    );

    renderGrades(filtered);
  });
};
