const grades = [
  {
    name: "SS304",
    elements: {
      C: "≤0.08%",
      Mn: "≤2.0%",
      Si: "≤1.0%",
      P: "≤0.045%",
      S: "≤0.03%",
      Cr: "18–20%",
      Ni: "8–10.5%"
    },
    standard: "ASTM A240"
  },
  {
    name: "SS316",
    elements: {
      C: "≤0.08%",
      Mn: "≤2.0%",
      Si: "≤1.0%",
      P: "≤0.045%",
      S: "≤0.03%",
      Cr: "16–18%",
      Ni: "10–14%",
      Mo: "2–3%"
    },
    standard: "ASTM A240"
  }
];
